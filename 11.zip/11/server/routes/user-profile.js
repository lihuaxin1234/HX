const express = require('express');
const router = express.Router();
const Resource = require('../models/Resource');

// 获取用户已下载的资源
router.get('/downloaded', async (req, res) => {
    try {
        // 从查询参数获取用户ID，如果没有则使用默认值
        const userId = req.query.userId || 'default-user-id';
        
        // 获取用户已下载的资源
        const resources = await Resource.getDownloadedResources(userId);
        
        res.json(resources);
    } catch (error) {
        console.error('获取用户已下载资源失败:', error);
        res.status(500).json({ error: '获取资源失败' });
    }
});

// 获取用户收藏的资源
router.get('/favorites', async (req, res) => {
    try {
        // 从查询参数获取用户ID，如果没有则使用默认值
        const userId = req.query.userId || 'default-user-id';
        
        // 获取用户收藏的资源
        const resources = await Resource.getFavoriteResources(userId);
        
        res.json(resources);
    } catch (error) {
        console.error('获取用户收藏资源失败:', error);
        res.status(500).json({ error: '获取资源失败' });
    }
});

// 获取用户喜欢的资源
router.get('/likes', async (req, res) => {
    try {
        // 从查询参数获取用户ID，如果没有则使用默认值
        const userId = req.query.userId || 'default-user-id';
        
        // 获取用户喜欢的资源
        const resources = await Resource.getLikedResources(userId);
        
        res.json(resources);
    } catch (error) {
        console.error('获取用户喜欢资源失败:', error);
        res.status(500).json({ error: '获取资源失败' });
    }
});

// 收藏资源
router.post('/favorite', async (req, res) => {
    try {
        const { userId, resourceId } = req.body;
        
        // 收藏资源
        await Resource.favoriteResource(userId, resourceId);
        
        res.json({ message: '收藏成功' });
    } catch (error) {
        console.error('收藏资源失败:', error);
        res.status(500).json({ error: '收藏失败' });
    }
});

// 取消收藏资源
router.delete('/favorite', async (req, res) => {
    try {
        const { userId, resourceId } = req.body;
        
        // 取消收藏资源
        await Resource.unfavoriteResource(userId, resourceId);
        
        res.json({ message: '取消收藏成功' });
    } catch (error) {
        console.error('取消收藏资源失败:', error);
        res.status(500).json({ error: '取消收藏失败' });
    }
});

// 喜欢资源
router.post('/like', async (req, res) => {
    try {
        const { userId, resourceId } = req.body;
        
        // 喜欢资源
        await Resource.likeResource(userId, resourceId);
        
        res.json({ message: '喜欢成功' });
    } catch (error) {
        console.error('喜欢资源失败:', error);
        res.status(500).json({ error: '喜欢失败' });
    }
});

// 取消喜欢资源
router.delete('/like', async (req, res) => {
    try {
        const { userId, resourceId } = req.body;
        
        // 取消喜欢资源
        await Resource.unlikeResource(userId, resourceId);
        
        res.json({ message: '取消喜欢成功' });
    } catch (error) {
        console.error('取消喜欢资源失败:', error);
        res.status(500).json({ error: '取消喜欢失败' });
    }
});

// 获取用户统计数据
router.get('/stats', async (req, res) => {
    try {
        // 从查询参数获取用户ID，如果没有则使用默认值
        const userId = req.query.userId || 'default-user-id';
        
        // 获取用户统计数据
        const stats = {
            uploads: await Resource.getCountByUserId(userId),
            downloads: 0, // 需要实现下载计数逻辑
            favorites: await Resource.getFavoriteCount(userId),
            likes: await Resource.getLikeCount(userId)
        };
        
        res.json(stats);
    } catch (error) {
        console.error('获取用户统计数据失败:', error);
        res.status(500).json({ error: '获取统计数据失败' });
    }
});

module.exports = router;