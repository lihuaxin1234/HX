const express = require('express');
const Resource = require('../models/Resource');

const router = express.Router();

// 获取所有资源
router.get('/', async (req, res) => {
  try {
    const resources = await Resource.findAll();
    res.json({ success: true, resources });
  } catch (error) {
    console.error('获取资源失败:', error);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

// 获取当前用户上传的资源
router.get('/my-uploads', async (req, res) => {
  try {
    // 这里应该从JWT token中获取用户ID
    // 暂时使用查询参数作为示例
    const userId = req.query.userId;
    if (!userId) {
      return res.status(400).json({ success: false, message: '缺少用户ID' });
    }
    
    const resources = await Resource.findByUserId(userId);
    res.json({ success: true, resources });
  } catch (error) {
    console.error('获取用户资源失败:', error);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

// 上传新资源
router.post('/upload', async (req, res) => {
  try {
    const resourceData = req.body;
    
    // 这里应该从JWT token中获取用户信息
    // 暂时使用请求体中的用户信息作为示例
    if (!resourceData.author || !resourceData.authorId) {
      return res.status(400).json({ success: false, message: '缺少作者信息' });
    }
    
    const newResource = await Resource.create(resourceData);
    res.status(201).json({ success: true, resource: newResource });
  } catch (error) {
    console.error('上传资源失败:', error);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

// 获取资源总数
router.get('/count', async (req, res) => {
  try {
    const count = await Resource.getCount();
    res.json({ success: true, count });
  } catch (error) {
    console.error('获取资源总数失败:', error);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

// 获取指定用户上传的资源数量
router.get('/count/my', async (req, res) => {
  try {
    // 这里应该从JWT token中获取用户ID
    // 暂时使用查询参数作为示例
    const userId = req.query.userId;
    if (!userId) {
      return res.status(400).json({ success: false, message: '缺少用户ID' });
    }
    
    const count = await Resource.getCountByUserId(userId);
    res.json({ success: true, count });
  } catch (error) {
    console.error('获取用户资源数量失败:', error);
    res.status(500).json({ success: false, message: '服务器内部错误' });
  }
});

module.exports = router;