const express = require('express');
const router = express.Router();
const Resource = require('../models/Resource');
const User = require('../models/User');

// 获取所有统计数据
router.get('/', async (req, res) => {
    try {
        const stats = {
            resourceCount: await Resource.getCount(),
            totalUsers: await User.getTotalUsers(),
            totalDownloads: await Resource.getTotalDownloads(),
            todayUploads: await Resource.getTodayUploads()
        };
        res.json(stats);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 实时更新统计数据 (用于长轮询或定期请求)
router.get('/updates', async (req, res) => {
    try {
        const lastUpdateTime = req.query.lastUpdate || 0;
        // 这里可以添加逻辑来检查数据是否有更新
        // 简化实现：直接返回最新数据
        const stats = {
            resourceCount: await Resource.getCount(),
            totalUsers: await User.getTotalUsers(),
            totalDownloads: await Resource.getTotalDownloads(),
            todayUploads: await Resource.getTodayUploads(),
            lastUpdated: Date.now()
        };
        res.json(stats);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;