const db = require('../config/database');

class User {
    // 获取注册用户总数
    static async getTotalUsers() {
        const query = 'SELECT COUNT(*) as count FROM users';
        
        try {
            const row = await db.get(query);
            return row.count;
        } catch (error) {
            throw new Error(`获取注册用户总数失败: ${error.message}`);
        }
    }
    // 根据ID查找用户
    static async findById(id) {
        const query = 'SELECT id, username, email, avatar FROM users WHERE id = ?';
        
        try {
            const user = await db.get(query, [id]);
            return user;
        } catch (error) {
            throw new Error(`查找用户失败: ${error.message}`);
        }
    }

    // 根据用户名查找用户
    static async findByUsername(username) {
        const query = 'SELECT * FROM users WHERE username = ?';
        
        try {
            const user = await db.get(query, [username]);
            return user;
        } catch (error) {
            throw new Error(`查找用户失败: ${error.message}`);
        }
    }

    // 根据邮箱查找用户
    static async findByEmail(email) {
        const query = 'SELECT * FROM users WHERE email = ?';
        
        try {
            const user = await db.get(query, [email]);
            return user;
        } catch (error) {
            throw new Error(`查找用户失败: ${error.message}`);
        }
    }

    // 创建新用户
    static async create(userData) {
        const { username, email, password } = userData;
        const query = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
        const params = [username, email, password];
        
        try {
            const result = await new Promise((resolve, reject) => {
                db.run(query, params, function(err) {
                    if (err) reject(err);
                    else resolve({ lastID: this.lastID });
                });
            });
            return { id: result.lastID, username, email };
        } catch (error) {
            throw new Error(`创建用户失败: ${error.message}`);
        }
    }

    // 更新用户信息
    static async update(id, userData) {
        const { username, email, avatar } = userData;
        const query = 'UPDATE users SET username = ?, email = ?, avatar = ? WHERE id = ?';
        const params = [username, email, avatar, id];
        
        try {
            await new Promise((resolve, reject) => {
                db.run(query, params, function(err) {
                    if (err) reject(err);
                    else resolve();
                });
            });
            return { id, username, email, avatar };
        } catch (error) {
            throw new Error(`更新用户信息失败: ${error.message}`);
        }
    }

    // 验证用户密码
    static async validatePassword(username, password) {
        const query = 'SELECT * FROM users WHERE username = ?';
        
        try {
            const user = await db.get(query, [username]);
            if (user && user.password === password) { // 注意：实际应用中应使用加密密码比较
                return user;
            }
            return null;
        } catch (error) {
            throw new Error(`验证密码失败: ${error.message}`);
        }
    }
    // 获取今日注册用户数
    static async getTodayUsers() {
        const query = `SELECT COUNT(*) as count FROM users WHERE date(created_at) = date('now')`;
        
        try {
            const row = await db.get(query);
            return row.count;
        } catch (error) {
            throw new Error(`获取今日注册用户数失败: ${error.message}`);
        }
    }
}

module.exports = User;