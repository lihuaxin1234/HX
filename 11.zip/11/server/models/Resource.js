const db = require('../config/database');

class Resource {
    // 获取总下载量
    static async getTotalDownloads() {
        const query = 'SELECT COUNT(*) as count FROM downloads';
        
        try {
            const row = await db.get(query);
            return row.count;
        } catch (error) {
            throw new Error(`获取总下载量失败: ${error.message}`);
        }
    }

    // 获取今日上传量
    static async getTodayUploads() {
        const query = `SELECT COUNT(*) as count FROM resources WHERE date(created_at) = date('now')`;
        
        try {
            const row = await db.get(query);
            return row.count;
        } catch (error) {
            throw new Error(`获取今日上传量失败: ${error.message}`);
        }
    }
    // 创建资源
    static async create(resourceData) {
        const { name, description, category, file_path, image_url, download_url, user_id } = resourceData;
        const query = `
            INSERT INTO resources (name, description, category, file_path, image_url, download_url, user_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        `;
        const params = [name, description, category, file_path, image_url, download_url, user_id];
        
        try {
            const result = await new Promise((resolve, reject) => {
                db.run(query, params, function(err) {
                    if (err) reject(err);
                    else resolve({ lastID: this.lastID });
                });
            });
            return { id: result.lastID, ...resourceData };
        } catch (error) {
            throw new Error(`创建资源失败: ${error.message}`);
        }
    }

    // 获取所有资源
    static async findAll() {
        const query = 'SELECT * FROM resources ORDER BY created_at DESC';
        
        try {
            const rows = await db.all(query);
            return rows;
        } catch (error) {
            throw new Error(`获取资源失败: ${error.message}`);
        }
    }

    // 根据用户ID获取资源
    static async findByUserId(userId) {
        const query = 'SELECT * FROM resources WHERE user_id = ? ORDER BY created_at DESC';
        
        try {
            const rows = await db.all(query, [userId]);
            return rows;
        } catch (error) {
            throw new Error(`获取用户资源失败: ${error.message}`);
        }
    }

    // 获取资源总数
    static async getCount() {
        const query = 'SELECT COUNT(*) as count FROM resources';
        
        try {
            const row = await db.get(query);
            return row.count;
        } catch (error) {
            throw new Error(`获取资源总数失败: ${error.message}`);
        }
    }

    // 根据用户ID获取资源数量
    static async getCountByUserId(userId) {
        const query = 'SELECT COUNT(*) as count FROM resources WHERE user_id = ?';
        
        try {
            const row = await db.get(query, [userId]);
            return row.count;
        } catch (error) {
            throw new Error(`获取用户资源数量失败: ${error.message}`);
        }
    }

    // 收藏资源
    static async favoriteResource(userId, resourceId) {
        const query = 'INSERT OR IGNORE INTO user_favorites (user_id, resource_id) VALUES (?, ?)';
        
        try {
            await new Promise((resolve, reject) => {
                db.run(query, [userId, resourceId], function(err) {
                    if (err) reject(err);
                    else resolve();
                });
            });
        } catch (error) {
            throw new Error(`收藏资源失败: ${error.message}`);
        }
    }

    // 取消收藏资源
    static async unfavoriteResource(userId, resourceId) {
        const query = 'DELETE FROM user_favorites WHERE user_id = ? AND resource_id = ?';
        
        try {
            await new Promise((resolve, reject) => {
                db.run(query, [userId, resourceId], function(err) {
                    if (err) reject(err);
                    else resolve();
                });
            });
        } catch (error) {
            throw new Error(`取消收藏资源失败: ${error.message}`);
        }
    }

    // 检查资源是否已被用户收藏
    static async isResourceFavorited(userId, resourceId) {
        const query = 'SELECT 1 FROM user_favorites WHERE user_id = ? AND resource_id = ?';
        
        try {
            const row = await db.get(query, [userId, resourceId]);
            return !!row;
        } catch (error) {
            throw new Error(`检查收藏状态失败: ${error.message}`);
        }
    }

    // 获取用户收藏的资源
    static async getFavoriteResources(userId) {
        const query = `
            SELECT r.*, 
                   uf.user_id as is_favorited,
                   ul.user_id as is_liked
            FROM resources r
            LEFT JOIN user_favorites uf ON r.id = uf.resource_id AND uf.user_id = ?
            LEFT JOIN user_likes ul ON r.id = ul.resource_id AND ul.user_id = ?
            WHERE r.id IN (SELECT resource_id FROM user_favorites WHERE user_id = ?)
            ORDER BY r.created_at DESC
        `;
        
        try {
            const rows = await db.all(query, [userId, userId, userId]);
            return rows.map(row => ({
                ...row,
                is_favorited: !!row.is_favorited,
                is_liked: !!row.is_liked
            }));
        } catch (error) {
            throw new Error(`获取收藏资源失败: ${error.message}`);
        }
    }

    // 喜欢资源
    static async likeResource(userId, resourceId) {
        const query = 'INSERT OR IGNORE INTO user_likes (user_id, resource_id) VALUES (?, ?)';
        
        try {
            await new Promise((resolve, reject) => {
                db.run(query, [userId, resourceId], function(err) {
                    if (err) reject(err);
                    else resolve();
                });
            });
        } catch (error) {
            throw new Error(`喜欢资源失败: ${error.message}`);
        }
    }

    // 取消喜欢资源
    static async unlikeResource(userId, resourceId) {
        const query = 'DELETE FROM user_likes WHERE user_id = ? AND resource_id = ?';
        
        try {
            await new Promise((resolve, reject) => {
                db.run(query, [userId, resourceId], function(err) {
                    if (err) reject(err);
                    else resolve();
                });
            });
        } catch (error) {
            throw new Error(`取消喜欢资源失败: ${error.message}`);
        }
    }

    // 检查资源是否已被用户喜欢
    static async isResourceLiked(userId, resourceId) {
        const query = 'SELECT 1 FROM user_likes WHERE user_id = ? AND resource_id = ?';
        
        try {
            const row = await db.get(query, [userId, resourceId]);
            return !!row;
        } catch (error) {
            throw new Error(`检查喜欢状态失败: ${error.message}`);
        }
    }

    // 获取用户喜欢的资源
    static async getLikedResources(userId) {
        const query = `
            SELECT r.*, 
                   uf.user_id as is_favorited,
                   ul.user_id as is_liked
            FROM resources r
            LEFT JOIN user_favorites uf ON r.id = uf.resource_id AND uf.user_id = ?
            LEFT JOIN user_likes ul ON r.id = ul.resource_id AND ul.user_id = ?
            WHERE r.id IN (SELECT resource_id FROM user_likes WHERE user_id = ?)
            ORDER BY r.created_at DESC
        `;
        
        try {
            const rows = await db.all(query, [userId, userId, userId]);
            return rows.map(row => ({
                ...row,
                is_favorited: !!row.is_favorited,
                is_liked: !!row.is_liked
            }));
        } catch (error) {
            throw new Error(`获取喜欢资源失败: ${error.message}`);
        }
    }

    // 记录下载
    static async recordDownload(userId, resourceId) {
        const query = 'INSERT OR IGNORE INTO user_downloads (user_id, resource_id, download_time) VALUES (?, ?, datetime(\'now\'))';
        
        try {
            await new Promise((resolve, reject) => {
                db.run(query, [userId, resourceId], function(err) {
                    if (err) reject(err);
                    else resolve();
                });
            });
        } catch (error) {
            throw new Error(`记录下载失败: ${error.message}`);
        }
    }

    // 获取用户下载的资源
    static async getDownloadedResources(userId) {
        const query = `
            SELECT r.*, 
                   uf.user_id as is_favorited,
                   ul.user_id as is_liked
            FROM resources r
            LEFT JOIN user_favorites uf ON r.id = uf.resource_id AND uf.user_id = ?
            LEFT JOIN user_likes ul ON r.id = ul.resource_id AND ul.user_id = ?
            WHERE r.id IN (SELECT resource_id FROM user_downloads WHERE user_id = ?)
            ORDER BY r.created_at DESC
        `;
        
        try {
            const rows = await db.all(query, [userId, userId, userId]);
            return rows.map(row => ({
                ...row,
                is_favorited: !!row.is_favorited,
                is_liked: !!row.is_liked
            }));
        } catch (error) {
            throw new Error(`获取下载资源失败: ${error.message}`);
        }
    }

    // 获取用户收藏数
    static async getFavoriteCount(userId) {
        const query = 'SELECT COUNT(*) as count FROM user_favorites WHERE user_id = ?';
        
        try {
            const row = await db.get(query, [userId]);
            return row.count;
        } catch (error) {
            throw new Error(`获取收藏数失败: ${error.message}`);
        }
    }

    // 获取用户喜欢数
    static async getLikeCount(userId) {
        const query = 'SELECT COUNT(*) as count FROM user_likes WHERE user_id = ?';
        
        try {
            const row = await db.get(query, [userId]);
            return row.count;
        } catch (error) {
            throw new Error(`获取喜欢数失败: ${error.message}`);
        }
    }
}

module.exports = Resource;