// 测试User模型修复后的功能
const User = require('./server/models/User');

// 测试获取用户总数
async function testTotalUsers() {
    try {
        const count = await User.getTotalUsers();
        console.log(`注册用户总数: ${count}`);
    } catch (error) {
        console.error('测试获取用户总数失败:', error.message);
    }
}

// 测试获取今日注册用户数
async function testTodayUsers() {
    try {
        const count = await User.getTodayUsers();
        console.log(`今日注册用户数: ${count}`);
    } catch (error) {
        console.error('测试获取今日注册用户数失败:', error.message);
    }
}

// 测试用户创建
async function testCreateUser() {
    try {
        const testUser = {
            username: 'testuser' + Date.now(),
            email: 'test' + Date.now() + '@example.com',
            password: 'testpassword'
        };
        const result = await User.create(testUser);
        console.log('创建用户成功:', result);
        return result.id;
    } catch (error) {
        console.error('测试创建用户失败:', error.message);
    }
}

// 测试用户更新
async function testUpdateUser(userId) {
    try {
        const updateData = {
            username: 'updateduser' + Date.now(),
            email: 'updated' + Date.now() + '@example.com',
            avatar: 'default-avatar.png'
        };
        const result = await User.update(userId, updateData);
        console.log('更新用户成功:', result);
    } catch (error) {
        console.error('测试更新用户失败:', error.message);
    }
}

// 运行所有测试
async function runAllTests() {
    console.log('开始测试User模型...');
    await testTotalUsers();
    await testTodayUsers();
    const userId = await testCreateUser();
    if (userId) {
        await testUpdateUser(userId);
        // 再次测试总数，确保创建成功
        await testTotalUsers();
        await testTodayUsers();
    }
    console.log('测试完成');
}

runAllTests();