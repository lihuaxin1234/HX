// API基础URL
const API_BASE_URL = 'http://localhost:3000/api/auth';

// 用户注册
async function registerUser(username, email, password) {
  try {
    const response = await fetch(`${API_BASE_URL}/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, email, password }),
    });

    const data = await response.json();
    
    if (response.ok) {
      // 保存用户信息和令牌到localStorage
      localStorage.setItem('currentUser', JSON.stringify(data.user));
      localStorage.setItem('token', data.token);
      return { success: true, user: data.user };
    } else {
      return { success: false, message: data.message };
    }
  } catch (error) {
    console.error('注册请求失败:', error);
    return { success: false, message: '网络错误，请稍后重试' };
  }
}

// 用户登录
async function loginUser(username, password) {
  try {
    const response = await fetch(`${API_BASE_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    const data = await response.json();
    
    if (response.ok) {
      // 保存用户信息和令牌到localStorage
      localStorage.setItem('currentUser', JSON.stringify(data.user));
      localStorage.setItem('token', data.token);
      return { success: true, user: data.user };
    } else {
      return { success: false, message: data.message };
    }
  } catch (error) {
    console.error('登录请求失败:', error);
    return { success: false, message: '网络错误，请稍后重试' };
  }
}

// 用户登出
function logoutUser() {
  localStorage.removeItem('currentUser');
  localStorage.removeItem('token');
}

// 检查用户是否已登录
function isAuthenticated() {
  return !!localStorage.getItem('token');
}

// 获取当前用户信息
function getCurrentUser() {
  const user = localStorage.getItem('currentUser');
  return user ? JSON.parse(user) : null;
}

// 更新用户信息
async function updateUserInfo(updates) {
  try {
    // 获取当前用户
    const currentUser = getCurrentUser();
    if (!currentUser) {
      return { success: false, message: '用户未登录' };
    }
    
    // 获取认证令牌
    const token = localStorage.getItem('token');
    if (!token) {
      return { success: false, message: '认证令牌缺失' };
    }
    
    // 发送更新请求
    const response = await fetch(`${API_BASE_URL}/update`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ id: currentUser.id, ...updates }),
    });
    
    const data = await response.json();
    
    if (response.ok) {
      // 更新localStorage中的用户信息
      const updatedUser = { ...currentUser, ...data.user };
      localStorage.setItem('currentUser', JSON.stringify(updatedUser));
      return { success: true, user: updatedUser };
    } else {
      return { success: false, message: data.message };
    }
  } catch (error) {
    console.error('更新用户信息失败:', error);
    return { success: false, message: '网络错误，请稍后重试' };
  }
}

// 导出函数
export { registerUser, loginUser, logoutUser, isAuthenticated, getCurrentUser, updateUserInfo };