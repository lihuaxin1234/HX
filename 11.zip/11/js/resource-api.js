// 资源API模块

// API基础URL
const API_BASE_URL = '/api/resources';

// 获取所有资源
async function getAllResources() {
  try {
    const response = await fetch(`${API_BASE_URL}/`);
    const data = await response.json();
    if (data.success) {
      return data.resources;
    } else {
      throw new Error(data.message || '获取资源失败');
    }
  } catch (error) {
    console.error('获取资源失败:', error);
    throw error;
  }
}

// 获取当前用户上传的资源
async function getUserUploads(userId) {
  try {
    const response = await fetch(`${API_BASE_URL}/my-uploads?userId=${userId}`);
    const data = await response.json();
    if (data.success) {
      return data.resources;
    } else {
      throw new Error(data.message || '获取用户资源失败');
    }
  } catch (error) {
    console.error('获取用户资源失败:', error);
    throw error;
  }
}

// 上传新资源
async function uploadResource(resourceData) {
  try {
    const response = await fetch(`${API_BASE_URL}/upload`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(resourceData)
    });
    
    const data = await response.json();
    if (data.success) {
      return data.resource;
    } else {
      throw new Error(data.message || '上传资源失败');
    }
  } catch (error) {
    console.error('上传资源失败:', error);
    throw error;
  }
}

// 获取资源总数
async function getResourceCount() {
  try {
    const response = await fetch(`${API_BASE_URL}/count`);
    const data = await response.json();
    if (data.success) {
      return data.count;
    } else {
      throw new Error(data.message || '获取资源总数失败');
    }
  } catch (error) {
    console.error('获取资源总数失败:', error);
    throw error;
  }
}

// 获取指定用户上传的资源数量
async function getUserResourceCount(userId) {
  try {
    const response = await fetch(`${API_BASE_URL}/count/my?userId=${userId}`);
    const data = await response.json();
    if (data.success) {
      return data.count;
    } else {
      throw new Error(data.message || '获取用户资源数量失败');
    }
  } catch (error) {
    console.error('获取用户资源数量失败:', error);
    throw error;
  }
}

// 获取用户下载的资源
async function getUserDownloads(userId) {
  try {
    const response = await fetch(`${API_BASE_URL}/user-profile/downloaded?userId=${userId}`);
    const data = await response.json();
    if (data.success) {
      return data.resources;
    } else {
      throw new Error(data.message || '获取用户下载资源失败');
    }
  } catch (error) {
    console.error('获取用户下载资源失败:', error);
    throw error;
  }
}

// 获取用户收藏的资源
async function getUserFavorites(userId) {
  try {
    const response = await fetch(`${API_BASE_URL}/user-profile/favorites?userId=${userId}`);
    const data = await response.json();
    if (data.success) {
      return data.resources;
    } else {
      throw new Error(data.message || '获取用户收藏资源失败');
    }
  } catch (error) {
    console.error('获取用户收藏资源失败:', error);
    throw error;
  }
}

// 获取用户喜欢的资源
async function getUserLikes(userId) {
  try {
    const response = await fetch(`${API_BASE_URL}/user-profile/likes?userId=${userId}`);
    const data = await response.json();
    if (data.success) {
      return data.resources;
    } else {
      throw new Error(data.message || '获取用户喜欢资源失败');
    }
  } catch (error) {
    console.error('获取用户喜欢资源失败:', error);
    throw error;
  }
}

// 收藏资源
async function favoriteResource(userId, resourceId) {
  try {
    const response = await fetch(`${API_BASE_URL}/user-profile/favorite`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId, resourceId })
    });
    
    const data = await response.json();
    if (data.success) {
      return data.result;
    } else {
      throw new Error(data.message || '收藏资源失败');
    }
  } catch (error) {
    console.error('收藏资源失败:', error);
    throw error;
  }
}

// 取消收藏资源
async function unfavoriteResource(userId, resourceId) {
  try {
    const response = await fetch(`${API_BASE_URL}/user-profile/favorite`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId, resourceId })
    });
    
    const data = await response.json();
    if (data.success) {
      return data.result;
    } else {
      throw new Error(data.message || '取消收藏资源失败');
    }
  } catch (error) {
    console.error('取消收藏资源失败:', error);
    throw error;
  }
}

// 喜欢资源
async function likeResource(userId, resourceId) {
  try {
    const response = await fetch(`${API_BASE_URL}/user-profile/like`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId, resourceId })
    });
    
    const data = await response.json();
    if (data.success) {
      return data.result;
    } else {
      throw new Error(data.message || '喜欢资源失败');
    }
  } catch (error) {
    console.error('喜欢资源失败:', error);
    throw error;
  }
}

// 取消喜欢资源
async function unlikeResource(userId, resourceId) {
  try {
    const response = await fetch(`${API_BASE_URL}/user-profile/like`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId, resourceId })
    });
    
    const data = await response.json();
    if (data.success) {
      return data.result;
    } else {
      throw new Error(data.message || '取消喜欢资源失败');
    }
  } catch (error) {
    console.error('取消喜欢资源失败:', error);
    throw error;
  }
}

// 切换收藏状态
export async function toggleFavorite(resourceId) {
  const token = localStorage.getItem('token');
  if (!token) {
    throw new Error('用户未登录');
  }

  // 先检查当前收藏状态
  const isFavorited = await isResourceFavorited(resourceId);
  
  if (isFavorited) {
    // 如果已收藏，则取消收藏
    return await unfavoriteResource(resourceId);
  } else {
    // 如果未收藏，则收藏
    return await favoriteResource(resourceId);
  }
}

// 切换喜欢状态
export async function toggleLike(resourceId) {
  const token = localStorage.getItem('token');
  if (!token) {
    throw new Error('用户未登录');
  }

  // 先检查当前喜欢状态
  const isLiked = await isResourceLiked(resourceId);
  
  if (isLiked) {
    // 如果已喜欢，则取消喜欢
    return await unlikeResource(resourceId);
  } else {
    // 如果未喜欢，则喜欢
    return await likeResource(resourceId);
  }
}

// 获取用户统计数据
async function getUserStats(userId) {
  try {
    const response = await fetch(`${API_BASE_URL}/user-profile/stats?userId=${userId}`);
    const data = await response.json();
    if (data.success) {
      return data.stats;
    } else {
      throw new Error(data.message || '获取用户统计数据失败');
    }
  } catch (error) {
    console.error('获取用户统计数据失败:', error);
    throw error;
  }
}

// 导出所有函数
export { 
  getAllResources, 
  getUserUploads, 
  uploadResource, 
  getResourceCount, 
  getUserResourceCount,
  getUserDownloads,
  getUserFavorites,
  getUserLikes,
  favoriteResource,
  unfavoriteResource,
  likeResource,
  unlikeResource,
  getUserStats
};