// 用户主页功能模块

// DOM加载完成后执行
document.addEventListener('DOMContentLoaded', async function() {
    // 检查用户是否已登录
    if (!isAuthenticated()) {
        // 如果未登录，重定向到登录页面
        window.location.href = 'index.html';
        return;
    }

    // 获取URL参数中的用户ID
    const urlParams = new URLSearchParams(window.location.search);
    const profileUserId = urlParams.get('userId');
    
    // 获取当前用户信息
    const currentUser = getCurrentUser();
    
    // 确定要显示的用户ID（如果URL中有指定用户ID则使用，否则显示当前用户）
    const targetUserId = profileUserId || currentUser.id;
    
    // 获取目标用户信息（这里简化处理，实际应该通过API获取）
    let targetUser = currentUser;
    if (profileUserId && profileUserId !== currentUser.id) {
        // 如果查看的是其他用户，需要获取该用户的信息
        // 这里暂时使用默认信息，实际应该通过API获取
        targetUser = {
            id: profileUserId,
            username: '其他用户',
            email: 'other@example.com',
            avatar: './images/user.jpg'
        };
    }
    
    // 更新页面上的用户信息
    document.getElementById('profile-username').textContent = targetUser.username;
    document.getElementById('profile-email').textContent = targetUser.email;
    document.getElementById('profile-avatar').src = targetUser.avatar || './images/user.jpg';
    
    // 获取用户统计数据
    await loadUserStats(targetUserId);
    
    // 加载默认标签页内容（已下载）
    await loadDownloadedResources(targetUserId);
    
    // 绑定标签页切换事件
    bindTabEvents(targetUserId);
});

// 绑定标签页切换事件
function bindTabEvents(targetUserId) {
    const tabButtons = document.querySelectorAll('.tab-button');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            // 移除所有活动状态
            tabButtons.forEach(btn => btn.classList.remove('tab-active'));
            
            // 添加当前按钮的活动状态
            this.classList.add('tab-active');
            
            // 隐藏所有标签页内容
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.add('hidden');
            });
            
            // 显示当前标签页内容
            const tabName = this.getAttribute('data-tab');
            document.getElementById(`${tabName}-content`).classList.remove('hidden');
            
            // 如果内容尚未加载，则加载内容
            if (tabName === 'downloaded' && document.getElementById('downloaded-resources').children.length <= 1) {
                loadDownloadedResources(targetUserId);
            } else if (tabName === 'favorites' && document.getElementById('favorite-resources').children.length <= 1) {
                loadFavoriteResources(targetUserId);
            } else if (tabName === 'likes' && document.getElementById('liked-resources').children.length <= 1) {
                loadLikedResources(targetUserId);
            }
        });
    });
}

// 获取用户统计数据
async function loadUserStats(userId) {
    try {
        // 获取用户统计数据
        const stats = await getUserStats(userId);
        document.getElementById('upload-count').textContent = stats.uploads;
        document.getElementById('download-count').textContent = stats.downloads;
        document.getElementById('favorite-count').textContent = stats.favorites;
        document.getElementById('like-count').textContent = stats.likes;
    } catch (error) {
        console.error('获取用户统计数据失败:', error);
    }
}

// 加载已下载的资源
async function loadDownloadedResources(userId) {
    try {
        // 显示加载状态
        const container = document.getElementById('downloaded-resources');
        container.innerHTML = '<div class="text-center py-8"><div class="w-8 h-8 border-4 border-gray-200 border-t-primary rounded-full loader mx-auto mb-3"></div><p>加载中...</p></div>';
        
        // 获取用户已下载的资源
        const resources = await getUserDownloads(userId);
        
        // 清空容器
        container.innerHTML = '';
        
        // 如果没有资源，显示空状态
        if (resources.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fa fa-download text-4xl mb-3"></i>
                    <p>暂无下载记录</p>
                </div>
            `;
            return;
        }
        
        // 添加资源卡片
        resources.forEach(resource => {
            const card = createResourceCard(resource, userId);
            container.appendChild(card);
        });
    } catch (error) {
        console.error('加载已下载资源失败:', error);
        document.getElementById('downloaded-resources').innerHTML = '<div class="text-center py-8 text-red-500"><p>加载失败，请稍后重试</p></div>';
    }
}

// 加载收藏的资源
async function loadFavoriteResources(userId) {
    try {
        // 显示加载状态
        const container = document.getElementById('favorite-resources');
        container.innerHTML = '<div class="text-center py-8"><div class="w-8 h-8 border-4 border-gray-200 border-t-primary rounded-full loader mx-auto mb-3"></div><p>加载中...</p></div>';
        
        // 获取用户收藏的资源
        const resources = await getUserFavorites(userId);
        
        // 清空容器
        container.innerHTML = '';
        
        // 如果没有资源，显示空状态
        if (resources.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fa fa-heart text-4xl mb-3"></i>
                    <p>暂无收藏记录</p>
                </div>
            `;
            return;
        }
        
        // 添加资源卡片
        resources.forEach(resource => {
            const card = createResourceCard(resource, userId);
            container.appendChild(card);
        });
    } catch (error) {
        console.error('加载收藏资源失败:', error);
        document.getElementById('favorite-resources').innerHTML = '<div class="text-center py-8 text-red-500"><p>加载失败，请稍后重试</p></div>';
    }
}

// 加载喜欢的资源
async function loadLikedResources(userId) {
    try {
        // 显示加载状态
        const container = document.getElementById('liked-resources');
        container.innerHTML = '<div class="text-center py-8"><div class="w-8 h-8 border-4 border-gray-200 border-t-primary rounded-full loader mx-auto mb-3"></div><p>加载中...</p></div>';
        
        // 获取用户喜欢的资源
        const resources = await getUserLikes(userId);
        
        // 清空容器
        container.innerHTML = '';
        
        // 如果没有资源，显示空状态
        if (resources.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fa fa-thumbs-up text-4xl mb-3"></i>
                    <p>暂无喜欢记录</p>
                </div>
            `;
            return;
        }
        
        // 添加资源卡片
        resources.forEach(resource => {
            const card = createResourceCard(resource, userId);
            container.appendChild(card);
        });
    } catch (error) {
        console.error('加载喜欢资源失败:', error);
        document.getElementById('liked-resources').innerHTML = '<div class="text-center py-8 text-red-500"><p>加载失败，请稍后重试</p></div>';
    }
}

// 创建资源卡片
function createResourceCard(resource, userId) {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow';
    card.innerHTML = `
        <div class="relative pb-2/3">
            <img src="${resource.image_url || './images/resource-default.jpg'}" alt="${resource.name}" class="absolute h-full w-full object-cover">
        </div>
        <div class="p-4">
            <h3 class="font-semibold text-lg mb-2">${resource.name}</h3>
            <p class="text-gray-600 text-sm mb-3">${resource.description || '暂无描述'}</p>
            <div class="flex justify-between items-center">
                <span class="text-primary font-medium">${resource.category}</span>
                <div class="flex space-x-2">
                    <button class="favorite-btn text-gray-500 hover:text-red-500" data-id="${resource.id}" title="收藏">
                        <i class="fa fa-heart${resource.is_favorited ? ' text-red-500' : ''}"></i>
                    </button>
                    <button class="like-btn text-gray-500 hover:text-blue-500" data-id="${resource.id}" title="喜欢">
                        <i class="fa fa-thumbs-up${resource.is_liked ? ' text-blue-500' : ''}"></i>
                    </button>
                    <button class="text-gray-500 hover:text-green-500 download-btn" data-id="${resource.id}" title="下载">
                        <i class="fa fa-download"></i>
                    </button>
                </div>
            </div>
        </div>
    `;
    
    // 添加收藏按钮事件
    const favoriteBtn = card.querySelector('.favorite-btn');
    favoriteBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        const resourceId = favoriteBtn.dataset.id;
        
        try {
            await toggleFavorite(resourceId);
            // 切换图标样式
            const icon = favoriteBtn.querySelector('i');
            icon.classList.toggle('text-red-500');
            
            // 重新加载当前标签页的数据
            const activeTab = document.querySelector('.tab-button.tab-active').getAttribute('data-tab');
            if (activeTab === 'favorites') {
                loadFavoriteResources(userId);
            }
            
            // 更新统计信息
            loadUserStats(userId);
        } catch (error) {
            console.error('收藏操作失败:', error);
            alert('操作失败，请稍后重试');
        }
    });
    
    // 添加喜欢按钮事件
    const likeBtn = card.querySelector('.like-btn');
    likeBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        const resourceId = likeBtn.dataset.id;
        
        try {
            await toggleLike(resourceId);
            // 切换图标样式
            const icon = likeBtn.querySelector('i');
            icon.classList.toggle('text-blue-500');
            
            // 重新加载当前标签页的数据
            const activeTab = document.querySelector('.tab-button.tab-active').getAttribute('data-tab');
            if (activeTab === 'likes') {
                loadLikedResources(userId);
            }
            
            // 更新统计信息
            loadUserStats(userId);
        } catch (error) {
            console.error('喜欢操作失败:', error);
            alert('操作失败，请稍后重试');
        }
    });
    
    // 添加下载按钮事件
    const downloadBtn = card.querySelector('.download-btn');
    downloadBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        const resourceId = downloadBtn.dataset.id;
        
        try {
            // 记录下载
            await recordDownload(resourceId);
            
            // 执行下载
            window.open(resource.download_url || '#', '_blank');
            
            // 更新统计信息
            loadUserStats(userId);
        } catch (error) {
            console.error('下载操作失败:', error);
            // 即使记录下载失败，也允许用户下载
            window.open(resource.download_url || '#', '_blank');
        }
    });
    
    return card;
}

// 添加加载动画样式
const style = document.createElement('style');
style.textContent = `
    .loader {
        border-top-color: #4CAF50;
        animation: spinner 0.6s linear infinite;
    }
    @keyframes spinner {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
`;
document.head.appendChild(style);