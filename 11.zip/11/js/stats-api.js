// 统计数据API
const STATS_API_URL = '/api/stats';

// 获取统计数据
export async function getStats() {
    try {
        const response = await fetch(STATS_API_URL);
        if (!response.ok) {
            throw new Error('获取统计数据失败');
        }
        return await response.json();
    } catch (error) {
        console.error('获取统计数据出错:', error);
        throw error;
    }
}

// 实时获取更新的统计数据
export async function getStatsUpdates(lastUpdateTime = 0) {
    try {
        const response = await fetch(`${STATS_API_URL}/updates?lastUpdate=${lastUpdateTime}`);
        if (!response.ok) {
            throw new Error('获取更新的统计数据失败');
        }
        return await response.json();
    } catch (error) {
        console.error('获取更新的统计数据出错:', error);
        throw error;
    }
}

// 轮询获取统计数据更新
export function startStatsPolling(updateInterval = 5000, callback) {
    let lastUpdateTime = 0;
    let pollingInterval;

    async function pollStats() {
        try {
            const stats = await getStatsUpdates(lastUpdateTime);
            if (stats.lastUpdated > lastUpdateTime) {
                lastUpdateTime = stats.lastUpdated;
                callback(stats);
            }
        } catch (error) {
            console.error('轮询统计数据出错:', error);
        }
    }

    // 立即执行一次
    pollStats();
    // 设置轮询间隔
    pollingInterval = setInterval(pollStats, updateInterval);

    // 返回停止轮询的函数
    return () => clearInterval(pollingInterval);
}