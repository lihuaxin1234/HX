// 完整的功能测试脚本
const User = require('./server/models/User');
const Resource = require('./server/models/Resource');
const db = require('./server/config/database');

// 测试前清理数据
async function clearTestData() {
    try {
        await new Promise((resolve, reject) => {
            db.run('DELETE FROM users WHERE username LIKE ?', ['testuser%'], function(err) {
                if (err) reject(err);
                else resolve();
            });
        });
        await new Promise((resolve, reject) => {
            db.run('DELETE FROM resources WHERE name LIKE ?', ['测试资源%'], function(err) {
                if (err) reject(err);
                else resolve();
            });
        });
        console.log('测试数据清理完成');
    } catch (error) {
        console.error('清理测试数据失败:', error.message);
    }
}

// 测试用户模型
async function testUserModel() {
    console.log('\n开始测试用户模型...');
    try {
        // 测试获取用户总数
        const initialCount = await User.getTotalUsers();
        console.log(`初始注册用户总数: ${initialCount}`);

        // 测试获取今日注册用户数
        const todayCount = await User.getTodayUsers();
        console.log(`今日注册用户数: ${todayCount}`);

        // 测试创建用户
        const testUser = {
            username: 'testuser' + Date.now(),
            email: 'test' + Date.now() + '@example.com',
            password: 'testpassword'
        };
        const createdUser = await User.create(testUser);
        console.log('创建用户成功:', createdUser);

        // 测试更新用户
        const updateData = {
            username: 'updateduser' + Date.now(),
            email: 'updated' + Date.now() + '@example.com',
            avatar: 'default-avatar.png'
        };
        const updatedUser = await User.update(createdUser.id, updateData);
        console.log('更新用户成功:', updatedUser);

        // 测试查找用户
        const foundUser = await User.findById(createdUser.id);
        console.log('查找用户成功:', foundUser);

        // 测试验证密码
        const validatedUser = await User.validatePassword(testUser.username, testUser.password);
        console.log('验证密码成功:', validatedUser ? '密码正确' : '密码错误');

        // 测试用户总数更新
        const newCount = await User.getTotalUsers();
        console.log(`创建用户后的注册用户总数: ${newCount}`);

        const newTodayCount = await User.getTodayUsers();
        console.log(`创建用户后的今日注册用户数: ${newTodayCount}`);

        console.log('用户模型测试通过！');
        return createdUser.id;
    } catch (error) {
        console.error('用户模型测试失败:', error.message);
        return null;
    }
}

// 测试资源模型
async function testResourceModel(userId) {
    if (!userId) {
        console.log('\n跳过资源模型测试，因为用户创建失败');
        return;
    }

    console.log('\n开始测试资源模型...');
    try {
        // 测试获取资源总数
        const initialCount = await Resource.getCount();
        console.log(`初始资源总数: ${initialCount}`);

        // 测试获取总下载量
        const initialDownloads = await Resource.getTotalDownloads();
        console.log(`初始总下载量: ${initialDownloads}`);

        // 测试获取今日上传量
        const todayUploads = await Resource.getTodayUploads();
        console.log(`今日上传量: ${todayUploads}`);

        // 测试创建资源
        const testResource = {
            name: '测试资源' + Date.now(),
            description: '这是一个测试资源',
            category: '测试',
            file_path: '/test/path',
            image_url: 'test-image.jpg',
            download_url: 'download/test',
            user_id: userId
        };
        const createdResource = await Resource.create(testResource);
        console.log('创建资源成功:', createdResource);

        // 测试收藏资源
        await Resource.favoriteResource(userId, createdResource.id);
        console.log('收藏资源成功');

        // 测试检查收藏状态
        const isFavorited = await Resource.isResourceFavorited(userId, createdResource.id);
        console.log(`收藏状态检查: ${isFavorited ? '已收藏' : '未收藏'}`);

        // 测试喜欢资源
        await Resource.likeResource(userId, createdResource.id);
        console.log('喜欢资源成功');

        // 测试检查喜欢状态
        const isLiked = await Resource.isResourceLiked(userId, createdResource.id);
        console.log(`喜欢状态检查: ${isLiked ? '已喜欢' : '未喜欢'}`);

        // 测试记录下载
        await Resource.recordDownload(userId, createdResource.id);
        console.log('记录下载成功');

        // 测试获取下载资源
        const downloadedResources = await Resource.getDownloadedResources(userId);
        console.log(`下载资源数量: ${downloadedResources.length}`);

        // 测试资源总数更新
        const newCount = await Resource.getCount();
        console.log(`创建资源后的资源总数: ${newCount}`);

        const newDownloads = await Resource.getTotalDownloads();
        console.log(`创建下载记录后的总下载量: ${newDownloads}`);

        const newTodayUploads = await Resource.getTodayUploads();
        console.log(`创建资源后的今日上传量: ${newTodayUploads}`);

        // 测试取消收藏
        await Resource.unfavoriteResource(userId, createdResource.id);
        console.log('取消收藏成功');

        // 测试取消喜欢
        await Resource.unlikeResource(userId, createdResource.id);
        console.log('取消喜欢成功');

        console.log('资源模型测试通过！');
    } catch (error) {
        console.error('资源模型测试失败:', error.message);
    }
}

// 测试统计数据
async function testStats() {
    console.log('\n开始测试统计数据...');
    try {
        // 获取统计数据
        const totalUsers = await User.getTotalUsers();
        const todayUsers = await User.getTodayUsers();
        const totalResources = await Resource.getCount();
        const totalDownloads = await Resource.getTotalDownloads();
        const todayUploads = await Resource.getTodayUploads();

        console.log('统计数据:');
        console.log(`- 注册用户总数: ${totalUsers}`);
        console.log(`- 今日注册用户数: ${todayUsers}`);
        console.log(`- 资源总数: ${totalResources}`);
        console.log(`- 总下载量: ${totalDownloads}`);
        console.log(`- 今日上传量: ${todayUploads}`);

        console.log('统计数据测试通过！');
    } catch (error) {
        console.error('统计数据测试失败:', error.message);
    }
}

// 运行所有测试
async function runAllTests() {
    console.log('开始运行所有测试...');
    await clearTestData();
    const userId = await testUserModel();
    await testResourceModel(userId);
    await testStats();
    console.log('\n所有测试完成！');
    console.log('请安装Node.js并运行server.js来启动应用。');
    console.log('访问http://localhost:3000/dashboard.html查看实时统计数据。');
    db.close();
}

runAllTests();